import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
export const show = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/checkout/{order}/pay',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
show.url = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'number' in args) {
            args = { order: args.number }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.number
                : args.order,
                }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
show.get = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
show.head = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
    const showForm = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
        showForm.get = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::show
 * @see app/Http/Controllers/PaymentController.php:21
 * @route '/checkout/{order}/pay'
 */
        showForm.head = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\PaymentController::start
 * @see app/Http/Controllers/PaymentController.php:44
 * @route '/checkout/{order}/pay'
 */
export const start = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/checkout/{order}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentController::start
 * @see app/Http/Controllers/PaymentController.php:44
 * @route '/checkout/{order}/pay'
 */
start.url = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'number' in args) {
            args = { order: args.number }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.number
                : args.order,
                }

    return start.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::start
 * @see app/Http/Controllers/PaymentController.php:44
 * @route '/checkout/{order}/pay'
 */
start.post = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PaymentController::start
 * @see app/Http/Controllers/PaymentController.php:44
 * @route '/checkout/{order}/pay'
 */
    const startForm = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PaymentController::start
 * @see app/Http/Controllers/PaymentController.php:44
 * @route '/checkout/{order}/pay'
 */
        startForm.post = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
export const returnMethod = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returnMethod.url(args, options),
    method: 'get',
})

returnMethod.definition = {
    methods: ["get","head"],
    url: '/payments/{payment}/return',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
returnMethod.url = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'uuid' in args) {
            args = { payment: args.uuid }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.uuid
                : args.payment,
                }

    return returnMethod.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
returnMethod.get = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returnMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
returnMethod.head = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: returnMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
    const returnMethodForm = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: returnMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
        returnMethodForm.get = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: returnMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:65
 * @route '/payments/{payment}/return'
 */
        returnMethodForm.head = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: returnMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    returnMethod.form = returnMethodForm
/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
export const cancel = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cancel.url(args, options),
    method: 'get',
})

cancel.definition = {
    methods: ["get","head"],
    url: '/payments/{payment}/cancel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
cancel.url = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'uuid' in args) {
            args = { payment: args.uuid }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.uuid
                : args.payment,
                }

    return cancel.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
cancel.get = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cancel.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
cancel.head = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cancel.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
    const cancelForm = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cancel.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
        cancelForm.get = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cancel.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:73
 * @route '/payments/{payment}/cancel'
 */
        cancelForm.head = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cancel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\PaymentController::verify
 * @see app/Http/Controllers/PaymentController.php:82
 * @route '/payments/{payment}/verify'
 */
export const verify = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/payments/{payment}/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentController::verify
 * @see app/Http/Controllers/PaymentController.php:82
 * @route '/payments/{payment}/verify'
 */
verify.url = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'uuid' in args) {
            args = { payment: args.uuid }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.uuid
                : args.payment,
                }

    return verify.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::verify
 * @see app/Http/Controllers/PaymentController.php:82
 * @route '/payments/{payment}/verify'
 */
verify.post = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PaymentController::verify
 * @see app/Http/Controllers/PaymentController.php:82
 * @route '/payments/{payment}/verify'
 */
    const verifyForm = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verify.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PaymentController::verify
 * @see app/Http/Controllers/PaymentController.php:82
 * @route '/payments/{payment}/verify'
 */
        verifyForm.post = (args: { payment: string | { uuid: string } } | [payment: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verify.url(args, options),
            method: 'post',
        })
    
    verify.form = verifyForm
const PaymentController = { show, start, returnMethod, cancel, verify, return: returnMethod }

export default PaymentController