import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NewsletterController::store
 * @see app/Http/Controllers/NewsletterController.php:17
 * @route '/newsletter'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/newsletter',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NewsletterController::store
 * @see app/Http/Controllers/NewsletterController.php:17
 * @route '/newsletter'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::store
 * @see app/Http/Controllers/NewsletterController.php:17
 * @route '/newsletter'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NewsletterController::store
 * @see app/Http/Controllers/NewsletterController.php:17
 * @route '/newsletter'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::store
 * @see app/Http/Controllers/NewsletterController.php:17
 * @route '/newsletter'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
export const showConfirm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showConfirm.url(args, options),
    method: 'get',
})

showConfirm.definition = {
    methods: ["get","head"],
    url: '/newsletter/confirm/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
showConfirm.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return showConfirm.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
showConfirm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showConfirm.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
showConfirm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showConfirm.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
    const showConfirmForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showConfirm.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
        showConfirmForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showConfirm.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NewsletterController::showConfirm
 * @see app/Http/Controllers/NewsletterController.php:47
 * @route '/newsletter/confirm/{token}'
 */
        showConfirmForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showConfirm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showConfirm.form = showConfirmForm
/**
* @see \App\Http\Controllers\NewsletterController::confirm
 * @see app/Http/Controllers/NewsletterController.php:58
 * @route '/newsletter/confirm/{token}'
 */
export const confirm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(args, options),
    method: 'post',
})

confirm.definition = {
    methods: ["post"],
    url: '/newsletter/confirm/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NewsletterController::confirm
 * @see app/Http/Controllers/NewsletterController.php:58
 * @route '/newsletter/confirm/{token}'
 */
confirm.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return confirm.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::confirm
 * @see app/Http/Controllers/NewsletterController.php:58
 * @route '/newsletter/confirm/{token}'
 */
confirm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NewsletterController::confirm
 * @see app/Http/Controllers/NewsletterController.php:58
 * @route '/newsletter/confirm/{token}'
 */
    const confirmForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: confirm.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::confirm
 * @see app/Http/Controllers/NewsletterController.php:58
 * @route '/newsletter/confirm/{token}'
 */
        confirmForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: confirm.url(args, options),
            method: 'post',
        })
    
    confirm.form = confirmForm
/**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
export const showUnsubscribe = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showUnsubscribe.url(args, options),
    method: 'get',
})

showUnsubscribe.definition = {
    methods: ["get","head"],
    url: '/newsletter/unsubscribe/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
showUnsubscribe.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return showUnsubscribe.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
showUnsubscribe.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showUnsubscribe.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
showUnsubscribe.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showUnsubscribe.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
    const showUnsubscribeForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showUnsubscribe.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
        showUnsubscribeForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showUnsubscribe.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NewsletterController::showUnsubscribe
 * @see app/Http/Controllers/NewsletterController.php:74
 * @route '/newsletter/unsubscribe/{token}'
 */
        showUnsubscribeForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showUnsubscribe.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showUnsubscribe.form = showUnsubscribeForm
/**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:85
 * @route '/newsletter/unsubscribe/{token}'
 */
export const unsubscribe = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(args, options),
    method: 'post',
})

unsubscribe.definition = {
    methods: ["post"],
    url: '/newsletter/unsubscribe/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:85
 * @route '/newsletter/unsubscribe/{token}'
 */
unsubscribe.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return unsubscribe.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:85
 * @route '/newsletter/unsubscribe/{token}'
 */
unsubscribe.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:85
 * @route '/newsletter/unsubscribe/{token}'
 */
    const unsubscribeForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unsubscribe.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:85
 * @route '/newsletter/unsubscribe/{token}'
 */
        unsubscribeForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unsubscribe.url(args, options),
            method: 'post',
        })
    
    unsubscribe.form = unsubscribeForm
const NewsletterController = { store, showConfirm, confirm, showUnsubscribe, unsubscribe }

export default NewsletterController