import Admin from './Admin'
import PreferenceController from './PreferenceController'
import NewsletterController from './NewsletterController'
import ContactController from './ContactController'
import CookieConsentController from './CookieConsentController'
import SitemapController from './SitemapController'
import Settings from './Settings'
import BlogController from './BlogController'
import ShopController from './ShopController'
import CartController from './CartController'
import CheckoutController from './CheckoutController'
import SearchController from './SearchController'
import ReviewController from './ReviewController'
import WishlistController from './WishlistController'
import PaymentController from './PaymentController'
import CartRecoveryController from './CartRecoveryController'
import Account from './Account'
import PageController from './PageController'
import PaymentWebhookController from './PaymentWebhookController'
const Controllers = {
    Admin: Object.assign(Admin, Admin),
PreferenceController: Object.assign(PreferenceController, PreferenceController),
NewsletterController: Object.assign(NewsletterController, NewsletterController),
ContactController: Object.assign(ContactController, ContactController),
CookieConsentController: Object.assign(CookieConsentController, CookieConsentController),
SitemapController: Object.assign(SitemapController, SitemapController),
Settings: Object.assign(Settings, Settings),
BlogController: Object.assign(BlogController, BlogController),
ShopController: Object.assign(ShopController, ShopController),
CartController: Object.assign(CartController, CartController),
CheckoutController: Object.assign(CheckoutController, CheckoutController),
SearchController: Object.assign(SearchController, SearchController),
ReviewController: Object.assign(ReviewController, ReviewController),
WishlistController: Object.assign(WishlistController, WishlistController),
PaymentController: Object.assign(PaymentController, PaymentController),
CartRecoveryController: Object.assign(CartRecoveryController, CartRecoveryController),
Account: Object.assign(Account, Account),
PageController: Object.assign(PageController, PageController),
PaymentWebhookController: Object.assign(PaymentWebhookController, PaymentWebhookController),
}

export default Controllers