import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CartRecoveryController::capture
 * @see app/Http/Controllers/CartRecoveryController.php:21
 * @route '/checkout/email'
 */
export const capture = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: capture.url(options),
    method: 'post',
})

capture.definition = {
    methods: ["post"],
    url: '/checkout/email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartRecoveryController::capture
 * @see app/Http/Controllers/CartRecoveryController.php:21
 * @route '/checkout/email'
 */
capture.url = (options?: RouteQueryOptions) => {
    return capture.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartRecoveryController::capture
 * @see app/Http/Controllers/CartRecoveryController.php:21
 * @route '/checkout/email'
 */
capture.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: capture.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CartRecoveryController::capture
 * @see app/Http/Controllers/CartRecoveryController.php:21
 * @route '/checkout/email'
 */
    const captureForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: capture.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CartRecoveryController::capture
 * @see app/Http/Controllers/CartRecoveryController.php:21
 * @route '/checkout/email'
 */
        captureForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: capture.url(options),
            method: 'post',
        })
    
    capture.form = captureForm
/**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
export const showRestore = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRestore.url(args, options),
    method: 'get',
})

showRestore.definition = {
    methods: ["get","head"],
    url: '/bag/restore/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
showRestore.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return showRestore.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
showRestore.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRestore.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
showRestore.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showRestore.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
    const showRestoreForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showRestore.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
        showRestoreForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRestore.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CartRecoveryController::showRestore
 * @see app/Http/Controllers/CartRecoveryController.php:42
 * @route '/bag/restore/{token}'
 */
        showRestoreForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRestore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showRestore.form = showRestoreForm
/**
* @see \App\Http\Controllers\CartRecoveryController::restore
 * @see app/Http/Controllers/CartRecoveryController.php:53
 * @route '/bag/restore/{token}'
 */
export const restore = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/bag/restore/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartRecoveryController::restore
 * @see app/Http/Controllers/CartRecoveryController.php:53
 * @route '/bag/restore/{token}'
 */
restore.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return restore.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartRecoveryController::restore
 * @see app/Http/Controllers/CartRecoveryController.php:53
 * @route '/bag/restore/{token}'
 */
restore.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CartRecoveryController::restore
 * @see app/Http/Controllers/CartRecoveryController.php:53
 * @route '/bag/restore/{token}'
 */
    const restoreForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CartRecoveryController::restore
 * @see app/Http/Controllers/CartRecoveryController.php:53
 * @route '/bag/restore/{token}'
 */
        restoreForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
export const showUnsubscribe = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showUnsubscribe.url(args, options),
    method: 'get',
})

showUnsubscribe.definition = {
    methods: ["get","head"],
    url: '/bag/reminders/unsubscribe/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
showUnsubscribe.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return showUnsubscribe.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
showUnsubscribe.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showUnsubscribe.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
showUnsubscribe.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showUnsubscribe.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
    const showUnsubscribeForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showUnsubscribe.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
        showUnsubscribeForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showUnsubscribe.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CartRecoveryController::showUnsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:64
 * @route '/bag/reminders/unsubscribe/{token}'
 */
        showUnsubscribeForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showUnsubscribe.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showUnsubscribe.form = showUnsubscribeForm
/**
* @see \App\Http\Controllers\CartRecoveryController::unsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:76
 * @route '/bag/reminders/unsubscribe/{token}'
 */
export const unsubscribe = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(args, options),
    method: 'post',
})

unsubscribe.definition = {
    methods: ["post"],
    url: '/bag/reminders/unsubscribe/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartRecoveryController::unsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:76
 * @route '/bag/reminders/unsubscribe/{token}'
 */
unsubscribe.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return unsubscribe.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartRecoveryController::unsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:76
 * @route '/bag/reminders/unsubscribe/{token}'
 */
unsubscribe.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CartRecoveryController::unsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:76
 * @route '/bag/reminders/unsubscribe/{token}'
 */
    const unsubscribeForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unsubscribe.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CartRecoveryController::unsubscribe
 * @see app/Http/Controllers/CartRecoveryController.php:76
 * @route '/bag/reminders/unsubscribe/{token}'
 */
        unsubscribeForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unsubscribe.url(args, options),
            method: 'post',
        })
    
    unsubscribe.form = unsubscribeForm
/**
* @see \App\Http\Controllers\CartRecoveryController::oneClick
 * @see app/Http/Controllers/CartRecoveryController.php:87
 * @route '/email/unsubscribe/cart/{token}'
 */
export const oneClick = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: oneClick.url(args, options),
    method: 'post',
})

oneClick.definition = {
    methods: ["post"],
    url: '/email/unsubscribe/cart/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartRecoveryController::oneClick
 * @see app/Http/Controllers/CartRecoveryController.php:87
 * @route '/email/unsubscribe/cart/{token}'
 */
oneClick.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return oneClick.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartRecoveryController::oneClick
 * @see app/Http/Controllers/CartRecoveryController.php:87
 * @route '/email/unsubscribe/cart/{token}'
 */
oneClick.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: oneClick.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CartRecoveryController::oneClick
 * @see app/Http/Controllers/CartRecoveryController.php:87
 * @route '/email/unsubscribe/cart/{token}'
 */
    const oneClickForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: oneClick.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CartRecoveryController::oneClick
 * @see app/Http/Controllers/CartRecoveryController.php:87
 * @route '/email/unsubscribe/cart/{token}'
 */
        oneClickForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: oneClick.url(args, options),
            method: 'post',
        })
    
    oneClick.form = oneClickForm
const CartRecoveryController = { capture, showRestore, restore, showUnsubscribe, unsubscribe, oneClick }

export default CartRecoveryController