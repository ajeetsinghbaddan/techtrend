import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/checkout',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CheckoutController::show
 * @see app/Http/Controllers/CheckoutController.php:25
 * @route '/checkout'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\CheckoutController::quote
 * @see app/Http/Controllers/CheckoutController.php:69
 * @route '/checkout/quote'
 */
export const quote = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: quote.url(options),
    method: 'post',
})

quote.definition = {
    methods: ["post"],
    url: '/checkout/quote',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CheckoutController::quote
 * @see app/Http/Controllers/CheckoutController.php:69
 * @route '/checkout/quote'
 */
quote.url = (options?: RouteQueryOptions) => {
    return quote.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::quote
 * @see app/Http/Controllers/CheckoutController.php:69
 * @route '/checkout/quote'
 */
quote.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: quote.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CheckoutController::quote
 * @see app/Http/Controllers/CheckoutController.php:69
 * @route '/checkout/quote'
 */
    const quoteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: quote.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CheckoutController::quote
 * @see app/Http/Controllers/CheckoutController.php:69
 * @route '/checkout/quote'
 */
        quoteForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: quote.url(options),
            method: 'post',
        })
    
    quote.form = quoteForm
/**
* @see \App\Http\Controllers\CheckoutController::store
 * @see app/Http/Controllers/CheckoutController.php:82
 * @route '/checkout'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CheckoutController::store
 * @see app/Http/Controllers/CheckoutController.php:82
 * @route '/checkout'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::store
 * @see app/Http/Controllers/CheckoutController.php:82
 * @route '/checkout'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CheckoutController::store
 * @see app/Http/Controllers/CheckoutController.php:82
 * @route '/checkout'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CheckoutController::store
 * @see app/Http/Controllers/CheckoutController.php:82
 * @route '/checkout'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
export const confirmation = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirmation.url(args, options),
    method: 'get',
})

confirmation.definition = {
    methods: ["get","head"],
    url: '/checkout/{order}/confirmation',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
confirmation.url = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'number' in args) {
            args = { order: args.number }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.number
                : args.order,
                }

    return confirmation.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
confirmation.get = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirmation.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
confirmation.head = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirmation.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
    const confirmationForm = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: confirmation.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
        confirmationForm.get = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: confirmation.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CheckoutController::confirmation
 * @see app/Http/Controllers/CheckoutController.php:123
 * @route '/checkout/{order}/confirmation'
 */
        confirmationForm.head = (args: { order: string | { number: string } } | [order: string | { number: string } ] | string | { number: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: confirmation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    confirmation.form = confirmationForm
const CheckoutController = { show, quote, store, confirmation }

export default CheckoutController