import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
export const show = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{fallbackPlaceholder}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
show.url = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fallbackPlaceholder: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fallbackPlaceholder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fallbackPlaceholder: args.fallbackPlaceholder,
                }

    return show.definition.url
            .replace('{fallbackPlaceholder}', parsedArgs.fallbackPlaceholder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
show.get = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
show.head = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
    const showForm = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
        showForm.get = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PageController::show
 * @see app/Http/Controllers/PageController.php:14
 * @route '/{fallbackPlaceholder}'
 */
        showForm.head = (args: { fallbackPlaceholder: string | number } | [fallbackPlaceholder: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const PageController = { show }

export default PageController