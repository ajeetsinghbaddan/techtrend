import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/account/addresses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\AddressController::index
 * @see app/Http/Controllers/Account/AddressController.php:13
 * @route '/account/addresses'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Account\AddressController::store
 * @see app/Http/Controllers/Account/AddressController.php:26
 * @route '/account/addresses'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/account/addresses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Account\AddressController::store
 * @see app/Http/Controllers/Account/AddressController.php:26
 * @route '/account/addresses'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\AddressController::store
 * @see app/Http/Controllers/Account/AddressController.php:26
 * @route '/account/addresses'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Account\AddressController::store
 * @see app/Http/Controllers/Account/AddressController.php:26
 * @route '/account/addresses'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Account\AddressController::store
 * @see app/Http/Controllers/Account/AddressController.php:26
 * @route '/account/addresses'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Account\AddressController::update
 * @see app/Http/Controllers/Account/AddressController.php:44
 * @route '/account/addresses/{address}'
 */
export const update = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/account/addresses/{address}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Account\AddressController::update
 * @see app/Http/Controllers/Account/AddressController.php:44
 * @route '/account/addresses/{address}'
 */
update.url = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { address: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    address: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        address: args.address,
                }

    return update.definition.url
            .replace('{address}', parsedArgs.address.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\AddressController::update
 * @see app/Http/Controllers/Account/AddressController.php:44
 * @route '/account/addresses/{address}'
 */
update.put = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Account\AddressController::update
 * @see app/Http/Controllers/Account/AddressController.php:44
 * @route '/account/addresses/{address}'
 */
    const updateForm = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Account\AddressController::update
 * @see app/Http/Controllers/Account/AddressController.php:44
 * @route '/account/addresses/{address}'
 */
        updateForm.put = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Account\AddressController::destroy
 * @see app/Http/Controllers/Account/AddressController.php:54
 * @route '/account/addresses/{address}'
 */
export const destroy = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/account/addresses/{address}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Account\AddressController::destroy
 * @see app/Http/Controllers/Account/AddressController.php:54
 * @route '/account/addresses/{address}'
 */
destroy.url = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { address: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    address: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        address: args.address,
                }

    return destroy.definition.url
            .replace('{address}', parsedArgs.address.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\AddressController::destroy
 * @see app/Http/Controllers/Account/AddressController.php:54
 * @route '/account/addresses/{address}'
 */
destroy.delete = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Account\AddressController::destroy
 * @see app/Http/Controllers/Account/AddressController.php:54
 * @route '/account/addresses/{address}'
 */
    const destroyForm = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Account\AddressController::destroy
 * @see app/Http/Controllers/Account/AddressController.php:54
 * @route '/account/addresses/{address}'
 */
        destroyForm.delete = (args: { address: string | number } | [address: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Account\AddressController::makeDefault
 * @see app/Http/Controllers/Account/AddressController.php:61
 * @route '/account/addresses/{address}/default/{type}'
 */
export const makeDefault = (args: { address: string | number, type: string | number } | [address: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: makeDefault.url(args, options),
    method: 'post',
})

makeDefault.definition = {
    methods: ["post"],
    url: '/account/addresses/{address}/default/{type}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Account\AddressController::makeDefault
 * @see app/Http/Controllers/Account/AddressController.php:61
 * @route '/account/addresses/{address}/default/{type}'
 */
makeDefault.url = (args: { address: string | number, type: string | number } | [address: string | number, type: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    address: args[0],
                    type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        address: args.address,
                                type: args.type,
                }

    return makeDefault.definition.url
            .replace('{address}', parsedArgs.address.toString())
            .replace('{type}', parsedArgs.type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\AddressController::makeDefault
 * @see app/Http/Controllers/Account/AddressController.php:61
 * @route '/account/addresses/{address}/default/{type}'
 */
makeDefault.post = (args: { address: string | number, type: string | number } | [address: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: makeDefault.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Account\AddressController::makeDefault
 * @see app/Http/Controllers/Account/AddressController.php:61
 * @route '/account/addresses/{address}/default/{type}'
 */
    const makeDefaultForm = (args: { address: string | number, type: string | number } | [address: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: makeDefault.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Account\AddressController::makeDefault
 * @see app/Http/Controllers/Account/AddressController.php:61
 * @route '/account/addresses/{address}/default/{type}'
 */
        makeDefaultForm.post = (args: { address: string | number, type: string | number } | [address: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: makeDefault.url(args, options),
            method: 'post',
        })
    
    makeDefault.form = makeDefaultForm
const AddressController = { index, store, update, destroy, makeDefault }

export default AddressController