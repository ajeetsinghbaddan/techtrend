import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/account/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\SettingsController::edit
 * @see app/Http/Controllers/Account/SettingsController.php:23
 * @route '/account/settings'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Account\SettingsController::update
 * @see app/Http/Controllers/Account/SettingsController.php:44
 * @route '/account/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/account/settings',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Account\SettingsController::update
 * @see app/Http/Controllers/Account/SettingsController.php:44
 * @route '/account/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\SettingsController::update
 * @see app/Http/Controllers/Account/SettingsController.php:44
 * @route '/account/settings'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Account\SettingsController::update
 * @see app/Http/Controllers/Account/SettingsController.php:44
 * @route '/account/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Account\SettingsController::update
 * @see app/Http/Controllers/Account/SettingsController.php:44
 * @route '/account/settings'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/account/settings/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\SettingsController::exportMethod
 * @see app/Http/Controllers/Account/SettingsController.php:83
 * @route '/account/settings/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const SettingsController = { edit, update, exportMethod, export: exportMethod }

export default SettingsController