import OverviewController from './OverviewController'
import OrderController from './OrderController'
import AddressController from './AddressController'
import SettingsController from './SettingsController'
const Account = {
    OverviewController: Object.assign(OverviewController, OverviewController),
OrderController: Object.assign(OrderController, OrderController),
AddressController: Object.assign(AddressController, AddressController),
SettingsController: Object.assign(SettingsController, SettingsController),
}

export default Account