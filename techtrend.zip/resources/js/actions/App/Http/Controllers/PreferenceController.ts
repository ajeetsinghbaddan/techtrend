import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PreferenceController::update
 * @see app/Http/Controllers/PreferenceController.php:17
 * @route '/preferences'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/preferences',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PreferenceController::update
 * @see app/Http/Controllers/PreferenceController.php:17
 * @route '/preferences'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PreferenceController::update
 * @see app/Http/Controllers/PreferenceController.php:17
 * @route '/preferences'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PreferenceController::update
 * @see app/Http/Controllers/PreferenceController.php:17
 * @route '/preferences'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PreferenceController::update
 * @see app/Http/Controllers/PreferenceController.php:17
 * @route '/preferences'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const PreferenceController = { update }

export default PreferenceController