import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SearchController::index
 * @see app/Http/Controllers/SearchController.php:26
 * @route '/search'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
export const suggest = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suggest.url(options),
    method: 'get',
})

suggest.definition = {
    methods: ["get","head"],
    url: '/search/suggest',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
suggest.url = (options?: RouteQueryOptions) => {
    return suggest.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
suggest.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suggest.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
suggest.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: suggest.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
    const suggestForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: suggest.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
        suggestForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: suggest.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SearchController::suggest
 * @see app/Http/Controllers/SearchController.php:92
 * @route '/search/suggest'
 */
        suggestForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: suggest.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    suggest.form = suggestForm
const SearchController = { index, suggest }

export default SearchController