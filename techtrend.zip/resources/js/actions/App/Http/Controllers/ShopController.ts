import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
export const collections = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: collections.url(options),
    method: 'get',
})

collections.definition = {
    methods: ["get","head"],
    url: '/collections',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
collections.url = (options?: RouteQueryOptions) => {
    return collections.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
collections.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: collections.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
collections.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: collections.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
    const collectionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: collections.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
        collectionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: collections.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShopController::collections
 * @see app/Http/Controllers/ShopController.php:29
 * @route '/collections'
 */
        collectionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: collections.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    collections.form = collectionsForm
/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
const listing23c7ce02d371851dac5931f2310529bd = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listing23c7ce02d371851dac5931f2310529bd.url(args, options),
    method: 'get',
})

listing23c7ce02d371851dac5931f2310529bd.definition = {
    methods: ["get","head"],
    url: '/collections/{collection}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
listing23c7ce02d371851dac5931f2310529bd.url = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collection: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { collection: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    collection: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        collection: typeof args.collection === 'object'
                ? args.collection.slug
                : args.collection,
                }

    return listing23c7ce02d371851dac5931f2310529bd.definition.url
            .replace('{collection}', parsedArgs.collection.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
listing23c7ce02d371851dac5931f2310529bd.get = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listing23c7ce02d371851dac5931f2310529bd.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
listing23c7ce02d371851dac5931f2310529bd.head = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: listing23c7ce02d371851dac5931f2310529bd.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
    const listing23c7ce02d371851dac5931f2310529bdForm = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: listing23c7ce02d371851dac5931f2310529bd.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
        listing23c7ce02d371851dac5931f2310529bdForm.get = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: listing23c7ce02d371851dac5931f2310529bd.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/collections/{collection}'
 */
        listing23c7ce02d371851dac5931f2310529bdForm.head = (args: { collection: string | { slug: string } } | [collection: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: listing23c7ce02d371851dac5931f2310529bd.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    listing23c7ce02d371851dac5931f2310529bd.form = listing23c7ce02d371851dac5931f2310529bdForm
    /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
const listing431eb3176f0b3b6628922509e73230e6 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listing431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'get',
})

listing431eb3176f0b3b6628922509e73230e6.definition = {
    methods: ["get","head"],
    url: '/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
listing431eb3176f0b3b6628922509e73230e6.url = (options?: RouteQueryOptions) => {
    return listing431eb3176f0b3b6628922509e73230e6.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
listing431eb3176f0b3b6628922509e73230e6.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listing431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
listing431eb3176f0b3b6628922509e73230e6.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: listing431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
    const listing431eb3176f0b3b6628922509e73230e6Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: listing431eb3176f0b3b6628922509e73230e6.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
        listing431eb3176f0b3b6628922509e73230e6Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: listing431eb3176f0b3b6628922509e73230e6.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShopController::listing
 * @see app/Http/Controllers/ShopController.php:55
 * @route '/products'
 */
        listing431eb3176f0b3b6628922509e73230e6Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: listing431eb3176f0b3b6628922509e73230e6.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    listing431eb3176f0b3b6628922509e73230e6.form = listing431eb3176f0b3b6628922509e73230e6Form

/**
* Multiple routes resolve to \App\Http\Controllers\ShopController::listing, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `listing['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const listing = {
    '/collections/{collection}': listing23c7ce02d371851dac5931f2310529bd,
    '/products': listing431eb3176f0b3b6628922509e73230e6,
}

/**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
export const product = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(args, options),
    method: 'get',
})

product.definition = {
    methods: ["get","head"],
    url: '/products/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
product.url = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { product: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                }

    return product.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
product.get = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
product.head = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
    const productForm = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: product.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
        productForm.get = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: product.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShopController::product
 * @see app/Http/Controllers/ShopController.php:105
 * @route '/products/{product}'
 */
        productForm.head = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: product.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    product.form = productForm
const ShopController = { collections, listing, product }

export default ShopController