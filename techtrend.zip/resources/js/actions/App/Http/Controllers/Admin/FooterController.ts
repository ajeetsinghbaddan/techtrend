import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/footer',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\FooterController::edit
 * @see app/Http/Controllers/Admin/FooterController.php:13
 * @route '/admin/footer'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\FooterController::update
 * @see app/Http/Controllers/Admin/FooterController.php:20
 * @route '/admin/footer'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/footer',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\FooterController::update
 * @see app/Http/Controllers/Admin/FooterController.php:20
 * @route '/admin/footer'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FooterController::update
 * @see app/Http/Controllers/Admin/FooterController.php:20
 * @route '/admin/footer'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\FooterController::update
 * @see app/Http/Controllers/Admin/FooterController.php:20
 * @route '/admin/footer'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\FooterController::update
 * @see app/Http/Controllers/Admin/FooterController.php:20
 * @route '/admin/footer'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const FooterController = { edit, update }

export default FooterController