import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProductController::addImages
 * @see app/Http/Controllers/Admin/ProductController.php:108
 * @route '/admin/products/{product}/images'
 */
export const addImages = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addImages.url(args, options),
    method: 'post',
})

addImages.definition = {
    methods: ["post"],
    url: '/admin/products/{product}/images',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::addImages
 * @see app/Http/Controllers/Admin/ProductController.php:108
 * @route '/admin/products/{product}/images'
 */
addImages.url = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { product: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                }

    return addImages.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::addImages
 * @see app/Http/Controllers/Admin/ProductController.php:108
 * @route '/admin/products/{product}/images'
 */
addImages.post = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addImages.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::addImages
 * @see app/Http/Controllers/Admin/ProductController.php:108
 * @route '/admin/products/{product}/images'
 */
    const addImagesForm = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addImages.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::addImages
 * @see app/Http/Controllers/Admin/ProductController.php:108
 * @route '/admin/products/{product}/images'
 */
        addImagesForm.post = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addImages.url(args, options),
            method: 'post',
        })
    
    addImages.form = addImagesForm
/**
* @see \App\Http\Controllers\Admin\ProductController::updateImage
 * @see app/Http/Controllers/Admin/ProductController.php:131
 * @route '/admin/products/{product}/images/{image}'
 */
export const updateImage = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateImage.url(args, options),
    method: 'put',
})

updateImage.definition = {
    methods: ["put"],
    url: '/admin/products/{product}/images/{image}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::updateImage
 * @see app/Http/Controllers/Admin/ProductController.php:131
 * @route '/admin/products/{product}/images/{image}'
 */
updateImage.url = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return updateImage.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::updateImage
 * @see app/Http/Controllers/Admin/ProductController.php:131
 * @route '/admin/products/{product}/images/{image}'
 */
updateImage.put = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateImage.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::updateImage
 * @see app/Http/Controllers/Admin/ProductController.php:131
 * @route '/admin/products/{product}/images/{image}'
 */
    const updateImageForm = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateImage.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::updateImage
 * @see app/Http/Controllers/Admin/ProductController.php:131
 * @route '/admin/products/{product}/images/{image}'
 */
        updateImageForm.put = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateImage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateImage.form = updateImageForm
/**
* @see \App\Http\Controllers\Admin\ProductController::deleteImage
 * @see app/Http/Controllers/Admin/ProductController.php:144
 * @route '/admin/products/{product}/images/{image}'
 */
export const deleteImage = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteImage.url(args, options),
    method: 'delete',
})

deleteImage.definition = {
    methods: ["delete"],
    url: '/admin/products/{product}/images/{image}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::deleteImage
 * @see app/Http/Controllers/Admin/ProductController.php:144
 * @route '/admin/products/{product}/images/{image}'
 */
deleteImage.url = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return deleteImage.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::deleteImage
 * @see app/Http/Controllers/Admin/ProductController.php:144
 * @route '/admin/products/{product}/images/{image}'
 */
deleteImage.delete = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteImage.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::deleteImage
 * @see app/Http/Controllers/Admin/ProductController.php:144
 * @route '/admin/products/{product}/images/{image}'
 */
    const deleteImageForm = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteImage.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::deleteImage
 * @see app/Http/Controllers/Admin/ProductController.php:144
 * @route '/admin/products/{product}/images/{image}'
 */
        deleteImageForm.delete = (args: { product: string | { slug: string }, image: number | { id: number } } | [product: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteImage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteImage.form = deleteImageForm
/**
* @see \App\Http\Controllers\Admin\ProductController::reorderImages
 * @see app/Http/Controllers/Admin/ProductController.php:155
 * @route '/admin/products/{product}/images/reorder'
 */
export const reorderImages = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderImages.url(args, options),
    method: 'post',
})

reorderImages.definition = {
    methods: ["post"],
    url: '/admin/products/{product}/images/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::reorderImages
 * @see app/Http/Controllers/Admin/ProductController.php:155
 * @route '/admin/products/{product}/images/reorder'
 */
reorderImages.url = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { product: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                }

    return reorderImages.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::reorderImages
 * @see app/Http/Controllers/Admin/ProductController.php:155
 * @route '/admin/products/{product}/images/reorder'
 */
reorderImages.post = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderImages.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::reorderImages
 * @see app/Http/Controllers/Admin/ProductController.php:155
 * @route '/admin/products/{product}/images/reorder'
 */
    const reorderImagesForm = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderImages.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::reorderImages
 * @see app/Http/Controllers/Admin/ProductController.php:155
 * @route '/admin/products/{product}/images/reorder'
 */
        reorderImagesForm.post = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderImages.url(args, options),
            method: 'post',
        })
    
    reorderImages.form = reorderImagesForm
/**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProductController::index
 * @see app/Http/Controllers/Admin/ProductController.php:22
 * @route '/admin/products'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/products/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProductController::create
 * @see app/Http/Controllers/Admin/ProductController.php:54
 * @route '/admin/products/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\ProductController::store
 * @see app/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/products'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::store
 * @see app/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/products'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::store
 * @see app/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/products'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::store
 * @see app/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/products'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::store
 * @see app/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/products'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
export const edit = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/products/{product}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
edit.url = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { product: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                }

    return edit.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
edit.get = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
edit.head = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
    const editForm = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
        editForm.get = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProductController::edit
 * @see app/Http/Controllers/Admin/ProductController.php:62
 * @route '/admin/products/{product}/edit'
 */
        editForm.head = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
export const update = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/products/{product}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
update.url = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { product: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                }

    return update.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
update.put = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
update.patch = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
    const updateForm = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
        updateForm.put = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\ProductController::update
 * @see app/Http/Controllers/Admin/ProductController.php:88
 * @route '/admin/products/{product}'
 */
        updateForm.patch = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\ProductController::destroy
 * @see app/Http/Controllers/Admin/ProductController.php:95
 * @route '/admin/products/{product}'
 */
export const destroy = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ProductController::destroy
 * @see app/Http/Controllers/Admin/ProductController.php:95
 * @route '/admin/products/{product}'
 */
destroy.url = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { product: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.slug
                : args.product,
                }

    return destroy.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductController::destroy
 * @see app/Http/Controllers/Admin/ProductController.php:95
 * @route '/admin/products/{product}'
 */
destroy.delete = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ProductController::destroy
 * @see app/Http/Controllers/Admin/ProductController.php:95
 * @route '/admin/products/{product}'
 */
    const destroyForm = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductController::destroy
 * @see app/Http/Controllers/Admin/ProductController.php:95
 * @route '/admin/products/{product}'
 */
        destroyForm.delete = (args: { product: string | { slug: string } } | [product: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ProductController = { addImages, updateImage, deleteImage, reorderImages, index, create, store, edit, update, destroy }

export default ProductController