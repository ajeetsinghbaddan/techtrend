import DashboardController from './DashboardController'
import HeaderController from './HeaderController'
import HeroController from './HeroController'
import FeaturesController from './FeaturesController'
import PromosController from './PromosController'
import MarqueeController from './MarqueeController'
import CtaController from './CtaController'
import PostController from './PostController'
import CategoryController from './CategoryController'
import BlogSectionController from './BlogSectionController'
import NewsletterController from './NewsletterController'
import FooterController from './FooterController'
import CollectionController from './CollectionController'
import ProductRowsController from './ProductRowsController'
import ProductController from './ProductController'
import OrderController from './OrderController'
import PageController from './PageController'
import ContactMessageController from './ContactMessageController'
import CookieBannerController from './CookieBannerController'
import ReviewController from './ReviewController'
import WishlistController from './WishlistController'
import CustomerController from './CustomerController'
import SearchInsightsController from './SearchInsightsController'
import PaymentGatewayController from './PaymentGatewayController'
import AbandonedCartController from './AbandonedCartController'
import SeoController from './SeoController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
HeaderController: Object.assign(HeaderController, HeaderController),
HeroController: Object.assign(HeroController, HeroController),
FeaturesController: Object.assign(FeaturesController, FeaturesController),
PromosController: Object.assign(PromosController, PromosController),
MarqueeController: Object.assign(MarqueeController, MarqueeController),
CtaController: Object.assign(CtaController, CtaController),
PostController: Object.assign(PostController, PostController),
CategoryController: Object.assign(CategoryController, CategoryController),
BlogSectionController: Object.assign(BlogSectionController, BlogSectionController),
NewsletterController: Object.assign(NewsletterController, NewsletterController),
FooterController: Object.assign(FooterController, FooterController),
CollectionController: Object.assign(CollectionController, CollectionController),
ProductRowsController: Object.assign(ProductRowsController, ProductRowsController),
ProductController: Object.assign(ProductController, ProductController),
OrderController: Object.assign(OrderController, OrderController),
PageController: Object.assign(PageController, PageController),
ContactMessageController: Object.assign(ContactMessageController, ContactMessageController),
CookieBannerController: Object.assign(CookieBannerController, CookieBannerController),
ReviewController: Object.assign(ReviewController, ReviewController),
WishlistController: Object.assign(WishlistController, WishlistController),
CustomerController: Object.assign(CustomerController, CustomerController),
SearchInsightsController: Object.assign(SearchInsightsController, SearchInsightsController),
PaymentGatewayController: Object.assign(PaymentGatewayController, PaymentGatewayController),
AbandonedCartController: Object.assign(AbandonedCartController, AbandonedCartController),
SeoController: Object.assign(SeoController, SeoController),
}

export default Admin