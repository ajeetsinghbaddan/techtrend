import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/header',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HeaderController::edit
 * @see app/Http/Controllers/Admin/HeaderController.php:13
 * @route '/admin/header'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\HeaderController::update
 * @see app/Http/Controllers/Admin/HeaderController.php:20
 * @route '/admin/header'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/header',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\HeaderController::update
 * @see app/Http/Controllers/Admin/HeaderController.php:20
 * @route '/admin/header'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeaderController::update
 * @see app/Http/Controllers/Admin/HeaderController.php:20
 * @route '/admin/header'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\HeaderController::update
 * @see app/Http/Controllers/Admin/HeaderController.php:20
 * @route '/admin/header'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeaderController::update
 * @see app/Http/Controllers/Admin/HeaderController.php:20
 * @route '/admin/header'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const HeaderController = { edit, update }

export default HeaderController