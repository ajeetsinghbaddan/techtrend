import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/seo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SeoController::edit
 * @see app/Http/Controllers/Admin/SeoController.php:18
 * @route '/admin/seo'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\SeoController::update
 * @see app/Http/Controllers/Admin/SeoController.php:47
 * @route '/admin/seo'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/seo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SeoController::update
 * @see app/Http/Controllers/Admin/SeoController.php:47
 * @route '/admin/seo'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SeoController::update
 * @see app/Http/Controllers/Admin/SeoController.php:47
 * @route '/admin/seo'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SeoController::update
 * @see app/Http/Controllers/Admin/SeoController.php:47
 * @route '/admin/seo'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SeoController::update
 * @see app/Http/Controllers/Admin/SeoController.php:47
 * @route '/admin/seo'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const SeoController = { edit, update }

export default SeoController