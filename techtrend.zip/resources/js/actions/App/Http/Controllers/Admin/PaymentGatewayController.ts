import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/payments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::index
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:17
 * @route '/admin/payments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::update
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:53
 * @route '/admin/payments/{gateway}'
 */
export const update = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/payments/{gateway}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::update
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:53
 * @route '/admin/payments/{gateway}'
 */
update.url = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gateway: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'key' in args) {
            args = { gateway: args.key }
        }
    
    if (Array.isArray(args)) {
        args = {
                    gateway: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        gateway: typeof args.gateway === 'object'
                ? args.gateway.key
                : args.gateway,
                }

    return update.definition.url
            .replace('{gateway}', parsedArgs.gateway.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::update
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:53
 * @route '/admin/payments/{gateway}'
 */
update.put = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::update
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:53
 * @route '/admin/payments/{gateway}'
 */
    const updateForm = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::update
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:53
 * @route '/admin/payments/{gateway}'
 */
        updateForm.put = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::clearCredentials
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:104
 * @route '/admin/payments/{gateway}/credentials'
 */
export const clearCredentials = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearCredentials.url(args, options),
    method: 'delete',
})

clearCredentials.definition = {
    methods: ["delete"],
    url: '/admin/payments/{gateway}/credentials',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::clearCredentials
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:104
 * @route '/admin/payments/{gateway}/credentials'
 */
clearCredentials.url = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gateway: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'key' in args) {
            args = { gateway: args.key }
        }
    
    if (Array.isArray(args)) {
        args = {
                    gateway: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        gateway: typeof args.gateway === 'object'
                ? args.gateway.key
                : args.gateway,
                }

    return clearCredentials.definition.url
            .replace('{gateway}', parsedArgs.gateway.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::clearCredentials
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:104
 * @route '/admin/payments/{gateway}/credentials'
 */
clearCredentials.delete = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearCredentials.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::clearCredentials
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:104
 * @route '/admin/payments/{gateway}/credentials'
 */
    const clearCredentialsForm = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clearCredentials.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::clearCredentials
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:104
 * @route '/admin/payments/{gateway}/credentials'
 */
        clearCredentialsForm.delete = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clearCredentials.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clearCredentials.form = clearCredentialsForm
/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::test
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:113
 * @route '/admin/payments/{gateway}/test'
 */
export const test = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/admin/payments/{gateway}/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::test
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:113
 * @route '/admin/payments/{gateway}/test'
 */
test.url = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gateway: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'key' in args) {
            args = { gateway: args.key }
        }
    
    if (Array.isArray(args)) {
        args = {
                    gateway: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        gateway: typeof args.gateway === 'object'
                ? args.gateway.key
                : args.gateway,
                }

    return test.definition.url
            .replace('{gateway}', parsedArgs.gateway.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::test
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:113
 * @route '/admin/payments/{gateway}/test'
 */
test.post = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::test
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:113
 * @route '/admin/payments/{gateway}/test'
 */
    const testForm = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PaymentGatewayController::test
 * @see app/Http/Controllers/Admin/PaymentGatewayController.php:113
 * @route '/admin/payments/{gateway}/test'
 */
        testForm.post = (args: { gateway: string | { key: string } } | [gateway: string | { key: string } ] | string | { key: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(args, options),
            method: 'post',
        })
    
    test.form = testForm
const PaymentGatewayController = { index, update, clearCredentials, test }

export default PaymentGatewayController