import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/customers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CustomerController::index
 * @see app/Http/Controllers/Admin/CustomerController.php:33
 * @route '/admin/customers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/admin/customers/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CustomerController::exportMethod
 * @see app/Http/Controllers/Admin/CustomerController.php:194
 * @route '/admin/customers/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
export const show = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/customers/{customer}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
show.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return show.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
show.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
show.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
    const showForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
        showForm.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CustomerController::show
 * @see app/Http/Controllers/Admin/CustomerController.php:69
 * @route '/admin/customers/{customer}'
 */
        showForm.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::updateNotes
 * @see app/Http/Controllers/Admin/CustomerController.php:128
 * @route '/admin/customers/{customer}/notes'
 */
export const updateNotes = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateNotes.url(args, options),
    method: 'patch',
})

updateNotes.definition = {
    methods: ["patch"],
    url: '/admin/customers/{customer}/notes',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::updateNotes
 * @see app/Http/Controllers/Admin/CustomerController.php:128
 * @route '/admin/customers/{customer}/notes'
 */
updateNotes.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return updateNotes.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::updateNotes
 * @see app/Http/Controllers/Admin/CustomerController.php:128
 * @route '/admin/customers/{customer}/notes'
 */
updateNotes.patch = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateNotes.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::updateNotes
 * @see app/Http/Controllers/Admin/CustomerController.php:128
 * @route '/admin/customers/{customer}/notes'
 */
    const updateNotesForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateNotes.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::updateNotes
 * @see app/Http/Controllers/Admin/CustomerController.php:128
 * @route '/admin/customers/{customer}/notes'
 */
        updateNotesForm.patch = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateNotes.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateNotes.form = updateNotesForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::toggleBlock
 * @see app/Http/Controllers/Admin/CustomerController.php:138
 * @route '/admin/customers/{customer}/block'
 */
export const toggleBlock = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBlock.url(args, options),
    method: 'post',
})

toggleBlock.definition = {
    methods: ["post"],
    url: '/admin/customers/{customer}/block',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::toggleBlock
 * @see app/Http/Controllers/Admin/CustomerController.php:138
 * @route '/admin/customers/{customer}/block'
 */
toggleBlock.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return toggleBlock.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::toggleBlock
 * @see app/Http/Controllers/Admin/CustomerController.php:138
 * @route '/admin/customers/{customer}/block'
 */
toggleBlock.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBlock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::toggleBlock
 * @see app/Http/Controllers/Admin/CustomerController.php:138
 * @route '/admin/customers/{customer}/block'
 */
    const toggleBlockForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleBlock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::toggleBlock
 * @see app/Http/Controllers/Admin/CustomerController.php:138
 * @route '/admin/customers/{customer}/block'
 */
        toggleBlockForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleBlock.url(args, options),
            method: 'post',
        })
    
    toggleBlock.form = toggleBlockForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::resendVerification
 * @see app/Http/Controllers/Admin/CustomerController.php:161
 * @route '/admin/customers/{customer}/verification'
 */
export const resendVerification = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendVerification.url(args, options),
    method: 'post',
})

resendVerification.definition = {
    methods: ["post"],
    url: '/admin/customers/{customer}/verification',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::resendVerification
 * @see app/Http/Controllers/Admin/CustomerController.php:161
 * @route '/admin/customers/{customer}/verification'
 */
resendVerification.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return resendVerification.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::resendVerification
 * @see app/Http/Controllers/Admin/CustomerController.php:161
 * @route '/admin/customers/{customer}/verification'
 */
resendVerification.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendVerification.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::resendVerification
 * @see app/Http/Controllers/Admin/CustomerController.php:161
 * @route '/admin/customers/{customer}/verification'
 */
    const resendVerificationForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resendVerification.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::resendVerification
 * @see app/Http/Controllers/Admin/CustomerController.php:161
 * @route '/admin/customers/{customer}/verification'
 */
        resendVerificationForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resendVerification.url(args, options),
            method: 'post',
        })
    
    resendVerification.form = resendVerificationForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::sendPasswordReset
 * @see app/Http/Controllers/Admin/CustomerController.php:150
 * @route '/admin/customers/{customer}/password-reset'
 */
export const sendPasswordReset = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendPasswordReset.url(args, options),
    method: 'post',
})

sendPasswordReset.definition = {
    methods: ["post"],
    url: '/admin/customers/{customer}/password-reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::sendPasswordReset
 * @see app/Http/Controllers/Admin/CustomerController.php:150
 * @route '/admin/customers/{customer}/password-reset'
 */
sendPasswordReset.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return sendPasswordReset.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::sendPasswordReset
 * @see app/Http/Controllers/Admin/CustomerController.php:150
 * @route '/admin/customers/{customer}/password-reset'
 */
sendPasswordReset.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendPasswordReset.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::sendPasswordReset
 * @see app/Http/Controllers/Admin/CustomerController.php:150
 * @route '/admin/customers/{customer}/password-reset'
 */
    const sendPasswordResetForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendPasswordReset.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::sendPasswordReset
 * @see app/Http/Controllers/Admin/CustomerController.php:150
 * @route '/admin/customers/{customer}/password-reset'
 */
        sendPasswordResetForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendPasswordReset.url(args, options),
            method: 'post',
        })
    
    sendPasswordReset.form = sendPasswordResetForm
/**
* @see \App\Http\Controllers\Admin\CustomerController::resetTwoFactor
 * @see app/Http/Controllers/Admin/CustomerController.php:177
 * @route '/admin/customers/{customer}/two-factor/reset'
 */
export const resetTwoFactor = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetTwoFactor.url(args, options),
    method: 'post',
})

resetTwoFactor.definition = {
    methods: ["post"],
    url: '/admin/customers/{customer}/two-factor/reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CustomerController::resetTwoFactor
 * @see app/Http/Controllers/Admin/CustomerController.php:177
 * @route '/admin/customers/{customer}/two-factor/reset'
 */
resetTwoFactor.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return resetTwoFactor.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerController::resetTwoFactor
 * @see app/Http/Controllers/Admin/CustomerController.php:177
 * @route '/admin/customers/{customer}/two-factor/reset'
 */
resetTwoFactor.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetTwoFactor.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CustomerController::resetTwoFactor
 * @see app/Http/Controllers/Admin/CustomerController.php:177
 * @route '/admin/customers/{customer}/two-factor/reset'
 */
    const resetTwoFactorForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetTwoFactor.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CustomerController::resetTwoFactor
 * @see app/Http/Controllers/Admin/CustomerController.php:177
 * @route '/admin/customers/{customer}/two-factor/reset'
 */
        resetTwoFactorForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetTwoFactor.url(args, options),
            method: 'post',
        })
    
    resetTwoFactor.form = resetTwoFactorForm
const CustomerController = { index, exportMethod, show, updateNotes, toggleBlock, resendVerification, sendPasswordReset, resetTwoFactor, export: exportMethod }

export default CustomerController