import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
export const lookup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: lookup.url(options),
    method: 'get',
})

lookup.definition = {
    methods: ["get","head"],
    url: '/admin/products/lookup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
lookup.url = (options?: RouteQueryOptions) => {
    return lookup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
lookup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: lookup.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
lookup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: lookup.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
    const lookupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: lookup.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
        lookupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: lookup.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProductRowsController::lookup
 * @see app/Http/Controllers/Admin/ProductRowsController.php:60
 * @route '/admin/products/lookup'
 */
        lookupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: lookup.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    lookup.form = lookupForm
/**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/product-rows',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProductRowsController::edit
 * @see app/Http/Controllers/Admin/ProductRowsController.php:18
 * @route '/admin/product-rows'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\ProductRowsController::update
 * @see app/Http/Controllers/Admin/ProductRowsController.php:33
 * @route '/admin/product-rows'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/product-rows',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProductRowsController::update
 * @see app/Http/Controllers/Admin/ProductRowsController.php:33
 * @route '/admin/product-rows'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductRowsController::update
 * @see app/Http/Controllers/Admin/ProductRowsController.php:33
 * @route '/admin/product-rows'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProductRowsController::update
 * @see app/Http/Controllers/Admin/ProductRowsController.php:33
 * @route '/admin/product-rows'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProductRowsController::update
 * @see app/Http/Controllers/Admin/ProductRowsController.php:33
 * @route '/admin/product-rows'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const ProductRowsController = { lookup, edit, update }

export default ProductRowsController