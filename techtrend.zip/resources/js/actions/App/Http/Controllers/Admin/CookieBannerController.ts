import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/cookie-banner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CookieBannerController::edit
 * @see app/Http/Controllers/Admin/CookieBannerController.php:13
 * @route '/admin/cookie-banner'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\CookieBannerController::update
 * @see app/Http/Controllers/Admin/CookieBannerController.php:28
 * @route '/admin/cookie-banner'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/cookie-banner',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\CookieBannerController::update
 * @see app/Http/Controllers/Admin/CookieBannerController.php:28
 * @route '/admin/cookie-banner'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CookieBannerController::update
 * @see app/Http/Controllers/Admin/CookieBannerController.php:28
 * @route '/admin/cookie-banner'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\CookieBannerController::update
 * @see app/Http/Controllers/Admin/CookieBannerController.php:28
 * @route '/admin/cookie-banner'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CookieBannerController::update
 * @see app/Http/Controllers/Admin/CookieBannerController.php:28
 * @route '/admin/cookie-banner'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const CookieBannerController = { edit, update }

export default CookieBannerController