import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/abandoned-carts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AbandonedCartController::index
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:16
 * @route '/admin/abandoned-carts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::updateSettings
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:68
 * @route '/admin/abandoned-carts/settings'
 */
export const updateSettings = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSettings.url(options),
    method: 'put',
})

updateSettings.definition = {
    methods: ["put"],
    url: '/admin/abandoned-carts/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::updateSettings
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:68
 * @route '/admin/abandoned-carts/settings'
 */
updateSettings.url = (options?: RouteQueryOptions) => {
    return updateSettings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AbandonedCartController::updateSettings
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:68
 * @route '/admin/abandoned-carts/settings'
 */
updateSettings.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSettings.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AbandonedCartController::updateSettings
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:68
 * @route '/admin/abandoned-carts/settings'
 */
    const updateSettingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSettings.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AbandonedCartController::updateSettings
 * @see app/Http/Controllers/Admin/AbandonedCartController.php:68
 * @route '/admin/abandoned-carts/settings'
 */
        updateSettingsForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSettings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSettings.form = updateSettingsForm
const AbandonedCartController = { index, updateSettings }

export default AbandonedCartController