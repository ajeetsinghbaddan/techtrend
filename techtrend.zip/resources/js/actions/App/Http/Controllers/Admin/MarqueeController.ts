import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/marquee',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\MarqueeController::edit
 * @see app/Http/Controllers/Admin/MarqueeController.php:12
 * @route '/admin/marquee'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\MarqueeController::update
 * @see app/Http/Controllers/Admin/MarqueeController.php:19
 * @route '/admin/marquee'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/marquee',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\MarqueeController::update
 * @see app/Http/Controllers/Admin/MarqueeController.php:19
 * @route '/admin/marquee'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MarqueeController::update
 * @see app/Http/Controllers/Admin/MarqueeController.php:19
 * @route '/admin/marquee'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\MarqueeController::update
 * @see app/Http/Controllers/Admin/MarqueeController.php:19
 * @route '/admin/marquee'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MarqueeController::update
 * @see app/Http/Controllers/Admin/MarqueeController.php:19
 * @route '/admin/marquee'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const MarqueeController = { edit, update }

export default MarqueeController