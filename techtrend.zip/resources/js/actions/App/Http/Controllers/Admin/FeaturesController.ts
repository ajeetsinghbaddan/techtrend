import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/features',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\FeaturesController::edit
 * @see app/Http/Controllers/Admin/FeaturesController.php:13
 * @route '/admin/features'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\FeaturesController::update
 * @see app/Http/Controllers/Admin/FeaturesController.php:20
 * @route '/admin/features'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/features',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\FeaturesController::update
 * @see app/Http/Controllers/Admin/FeaturesController.php:20
 * @route '/admin/features'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FeaturesController::update
 * @see app/Http/Controllers/Admin/FeaturesController.php:20
 * @route '/admin/features'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\FeaturesController::update
 * @see app/Http/Controllers/Admin/FeaturesController.php:20
 * @route '/admin/features'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\FeaturesController::update
 * @see app/Http/Controllers/Admin/FeaturesController.php:20
 * @route '/admin/features'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const FeaturesController = { edit, update }

export default FeaturesController